// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAELzaJUj-n00fSHpU7sPi24WKULIJYylI",
  authDomain: "top-todo.firebaseapp.com",
  projectId: "top-todo",
  storageBucket: "top-todo.appspot.com",
  messagingSenderId: "778125455152",
  appId: "1:778125455152:web:c64416dc16cbddd13ca2f5",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

class FirebaseAdapter {
  saveTodo() {
    // Saves a new message to Cloud Firestore.
    async function saveMessage(messageText) {
      // Add a new message entry to the Firebase database.
      try {
        await addDoc(collection(getFirestore(), "todos"), {
          name: getUserName(),
          text: messageText,
          profilePicUrl: getProfilePicUrl(),
          timestamp: serverTimestamp(),
        });
      } catch (error) {
        console.error("Error writing new message to Firebase Database", error);
      }
    }
  }
}
