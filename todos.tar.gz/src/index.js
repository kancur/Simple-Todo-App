import './style.css';
import App from './modules/App';

//initializing new App instance
const myApp = new App()

